# Crawlspace Estimate Generator

This Streamlit app uses GPT-4 to generate draft Xactimate-style restoration estimates from job notes and photos.

---

## 🔧 Setup Instructions (For Any Computer)

### 1. Clone the Repo or Download This Folder

If from GitHub:
```bash
git clone https://github.com/Mason817780/Estimator-App.git
cd Estimator-App
```

Or unzip this folder.

---

### 2. Install Python + Requirements

Make sure Python 3.10+ is installed, then run:

```bash
pip install -r requirements.txt
```

---

### 3. Add Your OpenAI API Key

Open `restoration_estimator.py` and replace:

```python
openai.api_key = "sk-REPLACE_THIS_WITH_YOUR_KEY"
```

with your real OpenAI API key.

---

### 4. Run the App

```bash
streamlit run restoration_estimator.py
```

It will launch in your browser at `http://localhost:8501`

---

Built by Mason817780 💪
